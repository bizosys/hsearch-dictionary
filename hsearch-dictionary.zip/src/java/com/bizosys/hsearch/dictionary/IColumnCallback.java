package com.bizosys.hsearch.dictionary;

public interface IColumnCallback {

	String[] massageColumns(String[] cols);
	
}
