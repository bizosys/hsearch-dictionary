import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import com.bizosys.hsearch.dictionary.DictionaryCreation;


public class DictionaryCreationTest {
	
	public static void main(String[] args) throws Exception {
		List<Integer> colIndexes = new ArrayList<Integer>();
		colIndexes.add(19);
		colIndexes.add(17);
		colIndexes.add(21);
		
		DictionaryCreation.getInstance().buildDictionary(
				"file:///C:/Users/abinash/Downloads/pharma_1-74.csv", 
				colIndexes, '|', '.', true, -1, new FillBlanks());

		FileWriter writer = new FileWriter("d://dictionary.txt");
		BufferedWriter writerB = new BufferedWriter(writer);
		DictionaryCreation.getInstance().print(writerB);
		writerB.close();
		writer.close();
	}
	
}
