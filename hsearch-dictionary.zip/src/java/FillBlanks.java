import com.bizosys.hsearch.dictionary.IColumnCallback;


public class FillBlanks implements IColumnCallback {

	@Override
	public String[] massageColumns(String[] cols) {
		if ( cols[19] == null ) cols[19] = "Unknown";
		else if ( "".equals(cols[19].trim() ) ) cols[19] = "Unknown";
		
		if ( cols[17] == null ) cols[17] = cols[19];
		else if ( "".equals(cols[17].trim() ) ) cols[17] = cols[19];

		if ( cols[21] == null ) cols[21] = cols[19];
		else if ( "".equals(cols[21].trim() ) ) cols[21] = cols[19];
		
		return cols;
	}

}
